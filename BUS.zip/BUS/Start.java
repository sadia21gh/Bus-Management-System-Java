import Classes.*;
import javax.swing.*;  
import java.awt.event.*; 
public class Start{
	
	public static void main(String[] args) {  
	 
		//new Login();
		//new SignUp();
		new DashBoard();
		//new AdminLogin();
		//new AdminDashboard();
		//new AdminDashboard1();
		//new AdminDashboard2();
		//new AdminDashboard3();
	} 
}



