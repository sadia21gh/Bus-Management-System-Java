package Classes;

/*import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
//import java.awt.event.ActionEvent;
//import java.ActionListener;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
*/

import javax.swing.*;  
import java.awt.event.*;
import java.awt.Color;
import java.awt.Font;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.file.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class SignUp implements ActionListener{
	JFrame signUpFrame;
	private JLabel fName,lName;
	ImageIcon icon = new ImageIcon("ALLPicture/ok1.png");
	private JLabel signUpImg,signUpImg2,userName,email,userPass,cpyrt,usernl1;
	private JTextField fNameText,lNameText,emailText,userNameText;
	private JPasswordField userPassword;
	private JButton signBtn,backBtn;

	public SignUp(){

		signUpFrame = new JFrame();

		//Font headerText = new Font("Montserrat",Font.BOLD,35);

		cpyrt = new JLabel("Copyright @2023, TEAM ROAR");
		cpyrt.setBounds(200,490,300,15);
		cpyrt.setForeground(Color.white);
		cpyrt.setFont(new Font("Segoe UI", Font.PLAIN, 10));
		signUpFrame.add(cpyrt);


		usernl1 = new JLabel("Create an Account");
		usernl1.setBounds(175,25,220,25);
		usernl1.setForeground(Color.white);
		usernl1.setFont(new Font("Segoe UI", Font.BOLD, 25));
		signUpFrame.add(usernl1);
		


		fName = new JLabel("First Name");
		fName.setBounds(175,76,200,30);
		fName.setForeground(Color.white);
		fName.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		signUpFrame.add(fName);

		fNameText = new JTextField();
		fNameText.setBounds(175,105,200,30);
		fNameText.setBackground(new Color(155,113,177));
		fNameText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		fNameText.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(255,255,255)));
		signUpFrame.add(fNameText);

		
		lName = new JLabel("Last Name");
		lName.setBounds(175,135,200,30);
		lName.setForeground(Color.white);
		lName.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		signUpFrame.add(lName);

		lNameText = new JTextField();
		lNameText.setBounds(175,165,200,30);
		lNameText.setBackground(new Color(155,113,177));
		lNameText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lNameText.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(255,255,255)));
		signUpFrame.add(lNameText);


		userName = new JLabel("Username");
		userName.setBounds(175,196,200,30);
		userName.setForeground(Color.white);
		userName.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		signUpFrame.add(userName);


		userNameText = new JTextField();
		userNameText.setBounds(175,225,200,30);
		userNameText.setBackground(new Color(151,119,181));
		userNameText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		userNameText.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(255,255,255)));
		signUpFrame.add(userNameText);


		email = new JLabel("Email");
		email.setBounds(175,255,200,30);
		email.setForeground(Color.white);
		email.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		signUpFrame.add(email);

		emailText = new JTextField();
		emailText.setBounds(175,285,200,30);
		emailText.setBackground(new Color(141,133,191));
		emailText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		emailText.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(255,255,255)));
		signUpFrame.add(emailText);


		
		
		userPass = new JLabel("Password");
		userPass.setBounds(175,315,200,30);
		userPass.setForeground(Color.white);
		userPass.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		signUpFrame.add(userPass);

		userPassword = new JPasswordField();
		userPassword.setBounds(175,345,200,30);
		userPassword.setBackground(new Color(131,144,200));
		userPassword.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		userPassword.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(255,255,255)));
		signUpFrame.add(userPassword);



		signBtn = new JButton("SignUp");
		signBtn.setBounds(150,390,120,30);
		signBtn.setForeground(Color.white);
		signBtn.setBackground(new Color(119,85,163));
		signBtn.setBorder(BorderFactory.createBevelBorder(0));
		signBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
		signBtn.setFocusable(false);
		signUpFrame.add(signBtn);

		
		backBtn = new JButton("Back");
		backBtn.setBounds(300,390,120,30);		
		backBtn.setForeground(Color.white);		
		backBtn.setBackground(new Color(119,85,163));
		backBtn.setBorder(BorderFactory.createBevelBorder(0));
		backBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
		backBtn.setFocusable(false);
		signUpFrame.add(backBtn);

		


		signUpImg = new JLabel();
		signUpImg.setIcon(new ImageIcon("ALLPicture/SignLast.jpg"));
		signUpImg.setBounds(0,0,550,550);
		signUpFrame.add(signUpImg);
		signUpFrame.setResizable(false);
		//signUpImg2 = new JLabel();		
		//signUpImg2.setIcon(new ImageIcon("ALLPicture/SignL.png"));
		//signUpImg2.setBounds(600,200,160,160);
		//signUpFrame.add(signUpImg2);
		

		//button action perform
		signBtn.addActionListener(this);
		backBtn.addActionListener(this);


		//frame build
		signUpFrame.setSize(550,550);
		signUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		signUpFrame.setLayout(null);
		signUpFrame.setTitle("Local Bus Route");
		
		//signUpFrame.getContentPane().setBackground(new Color(204,255,229));
		signUpFrame.setVisible(true);
		signUpFrame.setLocationRelativeTo(null);


	}

	public void actionPerformed(ActionEvent e) {  
         
       /* if(e.getSource()==backBtn)
		{  
			new Login();
			signUpFrame.setVisible(false);
			//System.exit(0);
			
        }  */

        if(e.getSource()==signBtn)
		{  
				
				String firstName = fNameText.getText(); // First Name
				String lastName = lNameText.getText(); // Last Name
                String email = emailText.getText().toLowerCase(); // User Name
                String username = userNameText.getText(); // Email
                String upassword = userPassword.getText(); // Password

                if (username.isEmpty() || upassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    //result = Integer.parseInt(tf5.getText());
                    if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || username.isEmpty()
                            || upassword.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill all of the fields.", "Warning!",
                                JOptionPane.WARNING_MESSAGE);
                    }else {

                        try {
                            File file = new File(".\\Data\\user_data.txt");
                            if (!file.exists()) {
                                file.createNewFile();
                            }
                            FileWriter fw = new FileWriter(file, true);
                            BufferedWriter bw = new BufferedWriter(fw);
                            PrintWriter pw = new PrintWriter(bw);

                            pw.println("First Name : " + firstName);
                            pw.println("Last Name : " + lastName);
                            pw.println("Email : " + email);
                            pw.println("Username : " + username);
                            pw.println("Password : " + upassword);
                            pw.println("===============================================");
                            pw.close();

                        } catch (Exception ex) {
                            System.out.print(ex);
                        }

                        JOptionPane.showMessageDialog(null, "Registration Successfully Completed.",
                                "Registration Complete", JOptionPane.INFORMATION_MESSAGE,icon);
                        	
                        	new Login();
                        	signUpFrame.setVisible(false);
                    }
                }
            
			
        }else if(e.getSource()==backBtn)
		{  
			new Login();
			signUpFrame.setVisible(false);
			//System.exit(0);
			
        }
}
	
}	